#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <signal.h>

void fun(int signo)
{
	printf("\n");
	printf("hello world\n");
}
void main()
{
	signal(SIGINT,fun);
	while(1);

}
