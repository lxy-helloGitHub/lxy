#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <signal.h>
void main()
{
	pid_t pid;

	pid = fork();
	if(pid<0)
	{
		perror("fork函数创建失败\n");
	}
	if(pid == 0)
	{
		printf("子进程创建成功，进入挂起状态\n");
		printf("子进程的进程号：%d,子进程的父进程号：%d\n",getpid(),getppid());
		pause();
		printf("测试是否挂起成功\n");
	}else
	{
		printf("父进程创建成功\n");
		printf("父进程的进程号：%d,父进程的父进程号：%d\n",getpid(),getppid());
		sleep(1);
		kill(pid,SIGINT);
	}
}
