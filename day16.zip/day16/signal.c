#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <signal.h>

typedef void (*sighandler_t)(int);

void fun1(int signo)
{
	printf("ctrl+c fun1");
}
void fun2(int signo)
{
	printf("ctrl+c fun2");
}

void fun3(int signo)
{
	printf("ctrl+/ fun3");
}
void fun4(int signo)
{
	printf("ctrl+/ fun4");
}
void main()
{

}
