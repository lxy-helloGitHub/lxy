#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <signal.h>

void main()
{
	sigset_t set1,set2;
	int ret = 0;

	sigemptyset(&set1);
	sigaddset(&set1,SIGINT);
	sigaddset(&set1,SIGQUIT);
	ret = sigismember(&set1,SIGQUIT);
	printf("sigquit是否在信号集？【%d】\n",ret);
	sigdelset(&set1,SIGQUIT);
	ret = sigismember(&set1,SIGQUIT);
	printf("sigquit是否在信号集？【%d】\n",ret);


	sigfillset(&set2);
	ret = sigismember(&set2,SIGQUIT);
	printf("sigquit是否在信号集？【%d】\n",ret);
}
