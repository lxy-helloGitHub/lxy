#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <signal.h>
void main(){
	pid_t pid;
	pid = fork();
	if(pid == 0)
	{
		printf("子进程创建成功\n");
		while(1)
		{
			printf("子进程正在运行\n");
			sleep(1);
		}
	}else
	{
		sleep(2);
		kill(pid,SIGINT);
	}
}
