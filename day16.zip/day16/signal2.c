#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <signal.h>

typedef void (*sighandler_t)(int);

void fun1(int signo)
{
	printf("ctrl+c fun1\n");
}
void fun2(int signo)
{
	printf("ctrl+c fun2\n");
}

void fun3(int signo)
{
	printf("ctrl+/ fun3\n");
}
void fun4(int signo)
{
	printf("ctrl+/ fun4\n");
}

void main()
{
	sighandler_t previous = NULL;
	previous = signal(SIGINT,fun1);
	printf("fun1:%p\n",previous);

	previous = signal(SIGINT,fun2);
	printf("fun2:%p\n",previous);
	
	previous = signal(SIGQUIT,fun3);
	printf("fun3:%p\n",previous);

	previous = signal(SIGQUIT,fun4);
	printf("fun4:%p\n",previous);

	pause();
	pause();
	while(1)
	{
		sleep(1);
		printf("while循环正在运行\n");
	}

}
